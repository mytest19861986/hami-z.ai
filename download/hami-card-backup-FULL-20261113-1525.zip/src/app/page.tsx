import Link from "next/link"
import { db } from "@/lib/db"
import { PublicHeader, PublicFooter } from "@/components/shared/public-chrome"
import { Button } from "@/components/ui/button"
import { Shamseh } from "@/components/shared/brand"
import { HomepageBannerSlider } from "@/components/home/homepage-banner-slider"
import { InstallAppButton } from "@/components/pwa/install-app-button"
import { ArrowLeft, Stethoscope, MapPin, ShieldCheck, Clock3, HeartHandshake, Star } from "lucide-react"
import { formatToman } from "@/lib/format"
import { toFaDigits, faDate } from "@/lib/jalali"

export const dynamic = "force-dynamic"

async function getData() {
  const now = new Date()
  // پزشکان منتخب: تأییدشده + عمومی؛ اولویت با پزشکان دارای نظرات تأییدشدهٔ بیشینه
  // (میانگین ستاره × لگاریتم تعداد رأی — رتبهٔ اعتماد؛ بدون رأی، بر اساس جدیدترین)
  const [plans, doctorsRaw, activeMemberships, doctorCount, banners] = await Promise.all([
    db.discountPlan.findMany({ where: { isActive: true }, orderBy: { sortOrder: "asc" }, take: 3 }),
    db.doctor.findMany({
      where: { status: "APPROVED", isPublic: true },
      include: {
        user: { select: { profile: { select: { firstName: true, lastName: true } } } },
        reviews: { where: { status: "APPROVED" }, select: { rating: true } },
      },
      take: 60,
      orderBy: { createdAt: "desc" },
    }),
    db.membership.count({ where: { status: "ACTIVE", endDate: { gte: now } } }),
    db.doctor.count({ where: { status: "APPROVED", isPublic: true } }),
    // بنرهای فعال صفحهٔ اصلی (تنظیمات صفحه اصلی · ADMIN-023)
    db.homepageBanner.findMany({
      where: { isActive: true },
      orderBy: [{ sortOrder: "asc" }, { createdAt: "desc" }],
      select: { id: true, imageUrl: true, title: true, linkUrl: true },
      take: 10,
    }),
  ])

  // محاسبهٔ امتیاز و رتبه‌بندی (پزشکان با امتیاز بالا در بنر بالا می‌آیند)
  const doctors = doctorsRaw
    .map((d) => {
      const count = d.reviews.length
      const avg = count > 0 ? d.reviews.reduce((s, r) => s + r.rating, 0) / count : null
      // رتبهٔ اعتماد: میانگین وزن اصلی؛ تعداد رأی بیشتر، رتبه را تقویت می‌کند (log برای جلوگیری از غلبهٔ صرفاً تعدادی)
      const score = avg !== null ? avg * (1 + Math.log10(Math.max(1, count)) / 2) : -1
      return {
        id: d.id,
        specialty: d.specialty,
        clinicName: d.clinicName,
        province: d.province,
        city: d.city,
        discountPercent: d.discountPercent,
        user: d.user,
        ratingAvg: avg !== null ? Math.round(avg * 10) / 10 : null,
        ratingCount: count,
        score,
      }
    })
    .sort((a, b) => b.score - a.score)
    .slice(0, 6)

  return { plans, doctors, activeMemberships, doctorCount, banners }
}

const STEPS = [
  { n: "۰۱", title: "ثبت‌نام", desc: "فقط با شماره موبایل و کد تأیید؛ در چند ثانیه عضو شوید." },
  { n: "۰۲", title: "انتخاب طرح", desc: "طرح مناسب خود یا یکی از اعضای خانواده را تهیه کنید." },
  { n: "۰۳", title: "انتخاب پزشک", desc: "پزشک طرف قرارداد را در شهر خودتان پیدا و مراجعه کنید." },
  { n: "۰۴", title: "دریافت تخفیف", desc: "پزشک ویزیت را ثبت می‌کند و تخفیف طبق طرح شما اعمال می‌شود." },
]

export default async function HomePage() {
  const { plans, doctors, activeMemberships, doctorCount, banners } = await getData()

  return (
    <div className="flex min-h-screen flex-col">
      <PublicHeader />

      {/* ── هیرو ── */}
      <section className="relative overflow-hidden border-b border-border bg-card">
        <div className="pointer-events-none absolute -left-24 -top-24 text-primary/10">
          <Shamseh size={420} />
        </div>
        <div className="relative mx-auto grid max-w-6xl gap-12 px-4 py-16 lg:grid-cols-[1.15fr_0.85fr] lg:items-center lg:py-24">
          <div>
            <p className="inline-flex items-center gap-2 rounded-full border border-border bg-background px-3.5 py-1.5 text-xs text-muted-foreground">
              <span className="h-1.5 w-1.5 rounded-full bg-gold" />
              سامانهٔ عضویت و تخفیف خدمات درمانی
            </p>
            <h1 className="font-display mt-6 text-4xl font-extrabold leading-[1.25] sm:text-5xl">
              سلامتی شما،
              <br />
              با <span className="mark-gold text-primary">تخفیف واقعی</span>
            </h1>
            <p className="mt-6 max-w-xl text-[15px] leading-8 text-muted-foreground sm:text-base">
              با عضویت در حامی‌کارت، به شبکهٔ پزشکان طرف همکاری در سراسر ایران دسترسی پیدا کنید و در هر مراجعه از تخفیف
              طرح خود بهره‌مند شوید — بدون کاغذبازی، با ثبت شفاف ویزیت و تخفیف.
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <Button asChild size="lg" className="h-12 px-7 text-[15px]">
                <Link href="/plans">
                  مشاهدهٔ طرح‌های عضویت
                  <ArrowLeft className="mr-1 h-4 w-4" />
                </Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="h-12 px-6 text-[15px]">
                <Link href="/doctors">
                  <Stethoscope className="ml-1 h-4 w-4" />
                  پزشکان طرف قرارداد
                </Link>
              </Button>
              <InstallAppButton />
            </div>
            <dl className="mt-12 flex max-w-lg divide-x divide-x-reverse divide-border">
              <div className="px-5 text-center first:pr-0">
                <dd className="font-display text-3xl font-extrabold tabular-nums text-primary">{toFaDigits(doctorCount)}</dd>
                <dt className="mt-1 text-[11px] text-muted-foreground">پزشک طرف قرارداد</dt>
              </div>
              <div className="px-5 text-center">
                <dd className="font-display text-3xl font-extrabold tabular-nums text-primary">{toFaDigits(activeMemberships)}</dd>
                <dt className="mt-1 text-[11px] text-muted-foreground">عضویت فعال</dt>
              </div>
              <div className="px-5 text-center last:pl-0">
                <dd className="font-display text-3xl font-extrabold tabular-nums text-primary">۳۱</dd>
                <dt className="mt-1 text-[11px] text-muted-foreground">استمان پوشش</dt>
              </div>
            </dl>
          </div>

          {/* کارت برند پیش‌فرض (اسلاید اول همیشگی) + بنرهای اسلایدی ادمین (تنظیمات صفحه اصلی) */}
          <div className="relative">
            <HomepageBannerSlider
              banners={banners}
              recommendedPlan={
                plans[1]
                  ? {
                      title: plans[1].title,
                      price: formatToman(plans[1].price),
                      durationDays: plans[1].durationDays,
                    }
                  : null
              }
            />
          </div>
        </div>
      </section>

      {/* ── چطور کار می‌کند ── */}
      <section className="border-b border-border bg-card">
        <div className="mx-auto max-w-6xl px-4 py-16">
          <div className="mb-10 flex flex-col items-start justify-between gap-3 sm:flex-row sm:items-end">
            <div>
              <p className="text-xs font-bold uppercase tracking-wider text-gold-deep">مسیر عضویت</p>
              <h2 className="font-display mt-2 text-2xl font-extrabold sm:text-3xl">حامی‌کارت چطور کار می‌کند؟</h2>
            </div>
            <p className="max-w-xs text-sm leading-6 text-muted-foreground">در چهار قدم ساده تا تخفیف درمانی — بدون فرم کاغذی و مراجعهٔ حضوری.</p>
          </div>
          <div className="grid gap-x-8 gap-y-10 sm:grid-cols-2 lg:grid-cols-4">
            {STEPS.map((s, i) => (
              <div key={s.n} className={i < STEPS.length - 1 ? "lg:border-l lg:border-border/70 lg:pl-8" : ""}>
                <div className="font-display text-4xl font-extrabold tabular-nums text-gold">{s.n}</div>
                <h3 className="mt-3 font-bold">{s.title}</h3>
                <p className="mt-2 text-sm leading-7 text-muted-foreground">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── طرح‌ها ── */}
      <section className="mx-auto w-full max-w-6xl px-4 py-16">
        <div className="mb-10 flex items-end justify-between">
          <div>
            <p className="text-xs font-bold uppercase tracking-wider text-gold-deep">تعرفه‌ها</p>
            <h2 className="font-display mt-2 text-2xl font-extrabold sm:text-3xl">طرح‌های عضویت</h2>
            <p className="mt-2 text-sm text-muted-foreground">طرح مناسب خود یا عزیزانتان را انتخاب کنید</p>
          </div>
          <Button asChild variant="ghost" className="text-primary hover:text-primary">
            <Link href="/plans">
              همه طرح‌ها
              <ArrowLeft className="mr-1 h-4 w-4" />
            </Link>
          </Button>
        </div>
        <div className="grid gap-6 md:grid-cols-3">
          {plans.map((plan, i) => {
            const features: string[] = plan.features ? JSON.parse(plan.features) : []
            const featured = i === 1
            return (
              <div
                key={plan.id}
                className={
                  featured
                    ? "relative flex flex-col rounded-3xl border-2 border-gold/70 bg-card p-6 shadow-gold-soft"
                    : "relative flex flex-col rounded-3xl border border-border bg-card p-6 shadow-soft transition-shadow hover:shadow-float"
                }
              >
                <span className={featured ? "absolute -top-3.5 right-5 rounded-full bg-gold px-3.5 py-1 text-[11px] font-bold text-sidebar shadow-gold-soft" : "hidden"}>
                  پیشنهاد ما
                </span>
                <div className={featured ? "absolute inset-x-0 top-0 h-1 rounded-t-3xl bg-gold" : "absolute inset-x-0 top-0 h-1 rounded-t-3xl bg-primary/25"} />
                <h3 className="font-display text-lg font-bold">{plan.title}</h3>
                <p className="mt-1.5 min-h-10 text-sm leading-6 text-muted-foreground">{plan.description}</p>
                <div className="mt-5 flex items-baseline gap-1.5">
                  <span className="font-display text-3xl font-extrabold tabular-nums text-primary">{formatToman(plan.price)}</span>
                </div>
                <div className="mt-1.5 flex items-center gap-1.5 text-xs text-muted-foreground">
                  <Clock3 className="h-3.5 w-3.5" />
                  اعتبار {toFaDigits(plan.durationDays)} روز ·{" "}
                  {plan.usageLimit === null ? "استفاده نامحدود" : `${toFaDigits(plan.usageLimit)} مرتبه استفاده`}
                </div>
                <ul className="mt-5 flex-1 space-y-2.5 border-t border-border/70 pt-5 text-sm">
                  <li className="flex items-center gap-2 font-medium">
                    <ShieldCheck className="h-4 w-4 shrink-0 text-gold-deep" />
                    {toFaDigits(plan.discountPercent)}٪ تخفیف ویزیت پزشکان
                  </li>
                  {features.slice(0, 3).map((f) => (
                    <li key={f} className="flex items-center gap-2 text-muted-foreground">
                      <span className="h-1 w-1 shrink-0 rounded-full bg-gold" />
                      {f}
                    </li>
                  ))}
                </ul>
                <Button asChild className="mt-6 w-full" variant={featured ? "default" : "outline"}>
                  <Link href={`/plans/${plan.id}`}>جزئیات و خرید</Link>
                </Button>
              </div>
            )
          })}
        </div>
      </section>

      {/* ── پزشکان ── */}
      {doctors.length > 0 ? (
        <section className="border-y border-border bg-card">
          <div className="mx-auto max-w-6xl px-4 py-16">
            <div className="mb-10 flex items-end justify-between">
              <div>
                <p className="text-xs font-bold uppercase tracking-wider text-gold-deep">شبکهٔ درمانی</p>
                <h2 className="font-display mt-2 text-2xl font-extrabold sm:text-3xl">پزشکان طرف همکاری</h2>
                <p className="mt-2 text-sm text-muted-foreground">
                  {doctors[0]?.ratingAvg ? "برترین پزشکان بر اساس رضایت واقعی بیماران (نظرات تأییدشده)" : "نمونه‌ای از شبکهٔ پزشکان حامی‌کارت در سراسر کشور"}
                </p>
              </div>
              <Button asChild variant="ghost" className="text-primary hover:text-primary">
                <Link href="/doctors">
                  همه پزشکان
                  <ArrowLeft className="mr-1 h-4 w-4" />
                </Link>
              </Button>
            </div>
            <div className="divide-y divide-border/80">
              {doctors.map((d) => {
                const name = `${d.user.profile?.firstName ?? ""} ${d.user.profile?.lastName ?? ""}`.trim()
                const initials = `${d.user.profile?.firstName?.[0] ?? "د"}${d.user.profile?.lastName?.[0] ?? ""}`
                return (
                  <div key={d.id} className="flex min-h-[4.5rem] items-center gap-4 py-4 first:pt-2 last:pb-2">
                    <span className="font-display flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-secondary text-sm font-bold text-secondary-foreground">
                      {initials}
                    </span>
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
                        <h3 className="truncate text-sm font-bold">دکتر {name}</h3>
                        <span className="text-xs text-primary">{d.specialty}</span>
                        {/* امتیاز بیماران (نظرات تأییدشده) */}
                        {d.ratingAvg ? (
                          <span className="inline-flex items-center gap-1 rounded-full border border-amber-200 bg-amber-50 px-2 py-0.5">
                            {Array.from({ length: 5 }).map((_, i) => (
                              <Star
                                key={i}
                                className={`h-3 w-3 ${i < Math.round(d.ratingAvg!) ? "fill-amber-400 text-amber-500" : "text-amber-200"}`}
                              />
                            ))}
                            <span className="text-[11px] font-bold text-amber-700">{toFaDigits(d.ratingAvg!)}</span>
                            <span className="text-[10px] text-amber-600/80">({toFaDigits(d.ratingCount)} رأی)</span>
                          </span>
                        ) : null}
                      </div>
                      <div className="mt-1 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted-foreground">
                        {d.clinicName ? <span>{d.clinicName}</span> : null}
                        <span className="flex items-center gap-1">
                          <MapPin className="h-3.5 w-3.5" />
                          {d.province} / {d.city}
                        </span>
                      </div>
                    </div>
                    {d.discountPercent ? (
                      <span className="shrink-0 rounded-md bg-secondary px-2.5 py-1 text-[11px] font-bold tabular-nums text-secondary-foreground">
                        {toFaDigits(d.discountPercent)}٪ تخفیف اختصاصی
                      </span>
                    ) : null}
                  </div>
                )
              })}
            </div>
          </div>
        </section>
      ) : null}

      {/* ── CTA پایانی ── */}
      <section className="bg-brand-navy relative overflow-hidden text-primary-foreground">
        <div className="bg-girih-light absolute inset-0" />
        <div className="pointer-events-none absolute -left-16 -bottom-20 text-primary-foreground/20">
          <Shamseh size={280} />
        </div>
        <div className="relative mx-auto max-w-6xl px-4 py-16 text-center">
          <HeartHandshake className="mx-auto h-8 w-8 text-gold" />
          <h2 className="font-display mx-auto mt-4 max-w-2xl text-2xl font-extrabold leading-relaxed sm:text-3xl">
            همین حالا عضو حامی‌کارت شوید
          </h2>
          <p className="mx-auto mt-3 max-w-xl text-sm leading-7 text-primary-foreground/80">
            ثبت‌نام رایگان است؛ طرح را هر زمان خواستید به نام خودتان تهیه کنید و کارت تخفیف شما صادر خواهد شد.
          </p>
          <Button asChild size="lg" className="mt-7 h-12 bg-brand-gold px-8 text-[15px] text-sidebar shadow-gold-soft hover:brightness-105">
            <Link href="/auth/login">ورود / ثبت‌نام</Link>
          </Button>
          <p className="mt-5 text-[11px] tabular-nums text-primary-foreground/60">آخرین به‌روزرسانی: {faDate(new Date())}</p>
        </div>
      </section>

      <PublicFooter />
    </div>
  )
}
